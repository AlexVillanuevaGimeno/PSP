public class Main {
    public static void main(String[] args) {
        Client mi_cliente = new Client();
    }
}